const Router = require('express').Router()

const { sendRequest } = require('../http-client')
const { verifyAndDecodeToken } = require('../utils')

const IO_SERVICE_HOST = process.env.IO_SERVICE_HOST || 'localhost'

Router.get('/', async (req, res) => {
  console.info('Forwarding request for getting all challenges ...')

  const token = req.headers.authorization.split(' ')[1]
  const decoded = await verifyAndDecodeToken(token)

  const options = {
    url: `http://${IO_SERVICE_HOST}:3003/api/challenges/`,
    params: {
      userId: decoded.data.userId
    }
  }

  const response = await sendRequest(options)

  res.json(response)
})

Router.post('/', async (req, res) => {
  const { originalTestId, challengedUserId } = req.body

  console.info('Forwarding request for creating new challenge ...')

  const token = req.headers.authorization.split(' ')[1]

  const decoded = await verifyAndDecodeToken(token)

  const options = {
    url: `http://${IO_SERVICE_HOST}:3003/api/challenges/`,
    method: 'POST',
    data: {
      userId: decoded.data.id,
      originalTestId,
      challengedUserId
    }
  }

  const response = await sendRequest(options)

  res.json(response)
})

module.exports = Router