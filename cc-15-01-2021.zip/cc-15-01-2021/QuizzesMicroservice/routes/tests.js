const Router = require('express').Router()

const { sendRequest } = require('../http-client')
const { verifyAndDecodeToken } = require('../utils')

const IO_SERVICE_HOST = process.env.IO_SERVICE_HOST || 'localhost'

Router.get('/', async (req, res) => {
  const { id } = req.query

  console.log('Forwarding request for getting test by id ...')

  const token = req.headers.authorization.split(' ')[1]

  const decoded = await verifyAndDecodeToken(token)

  const options = {
    url: `http://${IO_SERVICE_HOST}:3003/api/tests`,
    params: {
      userId: decoded.data.id,
      testId: id
    }
  }

  const answers = await sendRequest(options)

  if (answers.length > 0) {
    const testStartTimestamp = answers[0].test_created_at
    const dates = answers.map(item => item.answer_created_at)
    const lastResponseTimestamp = dates.reduce((a, b) => (a.MeasureDate > b.MeasureDate ? a : b))

    const formattedAnswers = answers.map(item => {
      const formattedItem = { ...item }

      delete formattedItem.answer_created_at
      delete formattedItem.test_created_at

      return formattedItem
    })

    res.json({ testStart: testStartTimestamp, testFinish: lastResponseTimestamp, answers: formattedAnswers })
  } else {
    res.json({ answers: [] })
  }
})

Router.post('/', async (req, res) => {
  console.log('Creating a new test ...')

  const token = req.headers.authorization.split(' ')[1]
  const decoded = await verifyAndDecodeToken(token)

  const options = {
    url: `http://${IO_SERVICE_HOST}:3003/api/tests`,
    method: 'POST',
    data: {
      userId: decoded.data.id
    }
  }

  const response = await sendRequest(options)

  res.json(response)
})

Router.post('/answers', async (req, res) => {
  const { testId, questionId, answer } = req.body

  console.log('Adding new answer ...')

  const token = req.headers.authorization.split(' ')[1]
  const decoded = await verifyAndDecodeToken(token)

  const options = {
    url: `http://${IO_SERVICE_HOST}:3003/api/tests/answers`,
    method: 'POST',
    data: {
      userId: decoded.data.id,
      testId,
      questionId,
      answer
    }
  }

  await sendRequest(options)

  res.json({ success: true })
})


module.exports = Router
