import AxiosInstance from 'services/axios'

import config from 'services/axios/config'

import { User } from 'services/users/types'

export const getUsersByKeyword = async (keyword: string) => {
  try {
    const response = await AxiosInstance.get(`/api/users/?keyword=${keyword}`, config)

    return response.data.users as User[]
  } catch(e) {
    return e.status
  }
}