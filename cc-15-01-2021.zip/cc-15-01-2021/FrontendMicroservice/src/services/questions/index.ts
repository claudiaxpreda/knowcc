import AxiosInstance from 'services/axios'

import config from 'services/axios/config'

import { Question } from 'services/questions/types' 

export const getCategories = async () => {
  try {
    const response = await AxiosInstance.get('/api/questions/categories/', config)

    return response.data.categories as string[]
  } catch(e) {
    return e.status
  }
}

export const getQuestions = async (params: string) => {
  try {
    const response = await AxiosInstance.get(`/api/questions${params}/`, config)

    return response.data as Question[]
  } catch(e) {
    return e.status
  }
}

export const addAnswer = async (testId: number, answer: string, questionId: number) => {
  try {
    await AxiosInstance.post(`/api/tests/answers/`, {
      testId,
      answer,
      questionId
    }, config)
  } catch(e) {
    return e.status
  }
}


export const getTestResultById = async (testId: number) => {
  try {
    const response = await AxiosInstance.get(`/api/tests?id=${testId}`, config)

    return response.data
  } catch(e) {
    return e.status
  }
}