const config = {
  headers: {
    'Authorization': 'Bearer ' + localStorage.getItem('jwt_token')
  }
}

export default config