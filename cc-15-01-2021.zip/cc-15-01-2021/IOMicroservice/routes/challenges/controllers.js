const Router = require('express').Router()

const { createChallenge, getChallengesByUserID } = require('./services.js')

Router.get('/', async (req, res) => {
  const { userId } = req.query

  const response = await getChallengesByUserID(userId)

  res.json(response)
})

Router.post('/', async (req, res) => {
  const { originalTestId, challengedUserId } = req.body

  console.info('Creating a new challenge ...')

  try {
    await createChallenge(originalTestId, challengedUserId)

    res.json({ success: true })
  } catch (e) {
    res.status(500).json({ success: false })
  }
})

module.exports = Router
