const { query } = require('../../data')

const createChallenge = async (originalTestId, challengedUserId) => {
  console.log('Adding new challenge to database ...')

  try {
    await query(`INSERT INTO challenges(original_test_id, opponent_user_id) VALUES(${originalTestId}, ${challengedUserId})`)

    return true
  } catch (e) {
    console.log(e)
    return false
  }
}

const getChallengesByUserID = async (userId) => {
  console.log('Adding new challenge to database ...')

  try {
    const a = await query(`SELECT c.id, c.created_at, t.user_id as original_user_id, c.opponent_user_id, c.original_test_id, c.accepted_test_id FROM challenges c JOIN tests t ON c.original_test_id = t.id`)

    console.log(a)

    return true
  } catch (e) {
    console.log(e)
    return false
  }
}

module.exports = {
  createChallenge,
  getChallengesByUserID
}