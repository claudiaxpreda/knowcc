const { query } = require('../data')

const createTest = async (userId) => {
  console.info('Creating a new test entry ...')

  const newTest = await query(`INSERT INTO tests(user_id) VALUES (${userId}) returning id`)

  return newTest[0].id
}

const getTestById = async (userId, testId) => {
  console.info('Getting test by id ...')

  const tests = await query(`SELECT a.id, a.created_at as answer_created_at, t.created_at as test_created_at, a.answer, q.text, q.correct_answer, q.answer1, q.answer2, q.answer3, q.answer4, q.category, q.answers_count, q.correct_answers_count FROM answers a JOIN tests t ON t.id = a.test_id JOIN questions q ON q.id = a.question_id  WHERE t.user_id = ${userId} and t.id = ${testId}`)

  return tests
}

const addAnswer = async (testId, questionId, answer) => {
  console.info('Adding a new response ...')

  try {
    const question = await query(`SELECT * FROM questions WHERE id = ${questionId}`)

    const currentCount = parseInt(question[0].answers_count)
    const currentCorrectCount = parseInt(question[0].correct_answers_count)
    const isCorrect = question[0].correct_answer === answer ? 1 : 0

    await query(`UPDATE questions SET answers_count = ${currentCount + 1}, correct_answers_count = ${currentCorrectCount + isCorrect} WHERE id = ${questionId}`)
    await query(`INSERT INTO answers(test_id, question_id, answer) VALUES(${testId}, ${questionId}, '${answer}')`)

    return true
  } catch (e) {
    return false
  }
}

module.exports = {
  createTest,
  addAnswer,
  getTestById
}