const Router = require('express').Router()

const { createTest, addAnswer, getTestById } = require('./services.js')

Router.get('/', async (req, res) => {
  const { userId, testId } = req.query

  const tests = await getTestById(userId, testId)

  res.json(tests)
})

Router.post('/', async (req, res) => {
  const { userId } = req.body

  const testId = await createTest(userId)

  res.json(testId)
})

Router.post('/answers', async (req, res) => {
  const { testId, questionId, answer } = req.body

  await addAnswer(testId, questionId, answer)

  res.json({ success: true })
})

module.exports = Router
